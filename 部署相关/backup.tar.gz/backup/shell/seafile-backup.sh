#!/bin/bash
echo '备份数据库'
cd /opt/seafile-backup/databases

docker exec seafile-mysql mysqldump  -uroot -pzifeiyu --opt ccnet_db > ccnet_db.sql

docker exec seafile-mysql mysqldump  -uroot -pzifeiyu --opt seafile_db > seafile_db.sql

docker exec seafile-mysql mysqldump  -uroot -pzifeiyu --opt seahub_db > seahub_db.sql

echo '备份数据'
rsync -azv --delete /opt/seafile-data/seafile /opt/seafile-backup/data/ 
