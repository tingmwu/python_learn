#!/bin/bash
echo '恢复数据库'
docker cp /opt/seafile-backup/databases/ccnet_db.sql seafile-mysql:/tmp/ccnet_db.sql

docker cp /opt/seafile-backup/databases/seafile_db.sql seafile-mysql:/tmp/seafile_db.sql

docker cp /opt/seafile-backup/databases/seahub_db.sql seafile-mysql:/tmp/seahub_db.sql


docker exec -it seafile-mysql /bin/sh -c "mysql -uroot -pzifeiyu ccnet_db < /tmp/ccnet_db.sql"

docker exec -it seafile-mysql /bin/sh -c "mysql -uroot -pzifeiyu seafile_db < /tmp/seafile_db.sql"

docker exec -it seafile-mysql /bin/sh -c "mysql -uroot -pzifeiyu seahub_db < /tmp/seahub_db.sql"

echo '恢复数据'
rsync -az --delete /opt/seafile-backup/data/seafile/seafile-data /opt/seafile-data/seafile/
rsync -az --delete /opt/seafile-backup/data/seafile/seahub-data /opt/seafile-data/seafile/
