#!/bin/bash

work_path=$(dirname $0)

cd ${work_path}
wget -r -k -p -e robots=off --random-wait -U mozilla -P /home/tm/down https://www.axutongxue.com

