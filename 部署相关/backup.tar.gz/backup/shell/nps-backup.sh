#!/bin/bash
rsync -azv /etc/nps/conf /home/tm/backup/conf_nps 
