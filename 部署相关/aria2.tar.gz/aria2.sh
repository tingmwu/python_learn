#!/bin/bash
cd /home/tm/.aria2/
screen -S aria2 -dm aria2c
